﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Reflection.Metadata;
using System.Text;
using System.Threading.Tasks;

namespace OOD_first_project.Factories
{
    public class BinaryFactory
    {
        Dictionary<string, Func<byte[], object>> BinaryDic;
        public BinaryFactory() {
            BinaryDic = new Dictionary<string, Func<byte[], object>>()
        {
            { "NCR", newCrew },
            { "NPA",newPassenger },
            { "NCA",newCargoFactory },
            { "NCP",newCargoPlaneFactory},
            { "NPP",NewPassengerPlane },
            { "NAI",newAirPort},
            { "NFL",NewFlight },
        };
        }

        public void ReadFile(string path)
        {
            NetworkSourceSimulator.NetworkSourceSimulator Simulator = new NetworkSourceSimulator.NetworkSourceSimulator(path, 0,50);
            List<object> list = new List<object>();
            Simulator.OnNewDataReady += (sender, e) =>
            {
                //Console.WriteLine( Encoding.UTF8.GetString(Simulator.GetMessageAt(e.MessageIndex).MessageBytes));
                var data = Simulator.GetMessageAt(e.MessageIndex);
                var id = Encoding.UTF8.GetString(data.MessageBytes, 0, 3);
                list.Add(BinaryDic[id](data.MessageBytes));
            };
            Thread thread = new Thread(new ThreadStart(Simulator.Run));
            thread.Start();
            while (thread.IsAlive) {
            if (Console.ReadLine() == "print")
                {
                    Serializer serializer = new Serializer(list);
                    serializer.Serializ("app1.json");
                    Console.WriteLine("wrote_to_file");
                }
            else if(Console.ReadLine() == "Exit")
                {
                    thread.Interrupt();
                    break;
                }
            }
        }
        public object newCrew(byte[] data)
        {
            List<string> list = new List<string>();
            int position = 0;
            list.Add(Encoding.UTF8.GetString(data, position,3));
            position += 3;
            position += 4;
            list.Add(Encoding.UTF8.GetString(data, position,8));
            position += 8;
            list.Add(Encoding.UTF8.GetString(data, position,2));
            position += 2;
            var NameL = Encoding.UTF8.GetString(data, position, 2);
            position += 2;
            list.Add(Encoding.UTF8.GetString(data, position, int.Parse(NameL)));
            position += int.Parse(NameL);
            list.Add(Encoding.UTF8.GetString(data, position,2));
            position += 2;
            list.Add(Encoding.UTF8.GetString(data, position,12));
            position += 12;
            list.Add(Encoding.UTF8.GetString(data, position,2));
            position += 2;
            var EmailLength = Encoding.UTF8.GetString(data, position, 2);
            position += 2;
            list.Add(Encoding.UTF8.GetString(data, position, int.Parse(EmailLength)));
            position += int.Parse(EmailLength);
            list.Add(Encoding.UTF8.GetString(data, position,2));
            position += 2;
            list.Add(BitConverter.ToString(data, position,1));
            position += 1;


            FileReader fileReader = new FileReader();
            return fileReader.objectFactory["C"](list.ToArray());
        }
        public object newPassenger(byte[] data)
        {
            List<string> list = new List<string>();
            int position = 0;
            list.Add(Encoding.UTF8.GetString(data, position, 2));
            position += 3;
            
            position += 4;
            list.Add(Encoding.UTF8.GetString(data, position, 4));
            position += 8;
            list.Add(Encoding.UTF8.GetString(data, position, 8));
            position += 2;
            var Name = BitConverter.ToString(data, position);
            list.Add(Name);
            position += Name.Length;
            list.Add(Encoding.UTF8.GetString(data, position, 2));
            position += 2;
            list.Add(Encoding.UTF8.GetString(data, position, 12));
            position += 12;
            list.Add(Encoding.UTF8.GetString(data, position, 2));
            position += 2;
            var EmailLength = Encoding.UTF8.GetString(data, position, 2);
            position += 2;
            list.Add(Encoding.UTF8.GetString(data, position, int.Parse(EmailLength)));
            position += int.Parse(EmailLength);
            list.Add(Encoding.UTF8.GetString(data, position, 1));
            position += 1;
            list.Add(Encoding.UTF8.GetString(data, position, 8));
            position += 8;


            FileReader fileReader = new FileReader();
            return fileReader.objectFactory["P"](list.ToArray());
        }
        public object newCargoFactory(byte[] data)
        {
            List<string> list = new List<string>();
            int position = 0;
            list.Add(Encoding.UTF8.GetString(data, position, 3));
            position += 3;
            
            position += 4;
            list.Add(Encoding.UTF8.GetString(data, position, 8));
            position += 8;
            list.Add(Encoding.UTF8.GetString(data, position, 4));
            position += 4;
            list.Add(Encoding.UTF8.GetString(data, position, 6));
            position += 6;
            list.Add(Encoding.UTF8.GetString(data, position, 2));
            position += 2;
            var DL = Encoding.UTF8.GetString(data, position, 2);
            position += 2;
            list.Add(Encoding.UTF8.GetString(data, position, int.Parse(DL)));
            position += int.Parse(DL);



            FileReader fileReader = new FileReader();
            return fileReader.objectFactory["CA"](list.ToArray());
        }
        public object newCargoPlaneFactory(byte[] data)
        {
            List<string> list = new List<string>();
            int position = 0;
            list.Add(Encoding.UTF8.GetString(data, position, 3));
            position += 3;
            position += 4;
            list.Add(Encoding.UTF8.GetString(data, position, 8));
            position += 8;
            list.Add(Encoding.UTF8.GetString(data, position, 10));
            position += 10;
            list.Add(Encoding.UTF8.GetString(data, position, 3));
            position += 3;
            list.Add(Encoding.UTF8.GetString(data, position, 2));
            position += 2;
            var ML = Encoding.UTF8.GetString(data, position, 2);
            position += 2;
            list.Add(Encoding.UTF8.GetString(data, position, int.Parse(ML)));
            position+= int.Parse(ML);   
            list.Add(Encoding.UTF8.GetString(data, position, 4));
            position += 4;
            FileReader fileReader = new FileReader();
            return fileReader.objectFactory["CP"](list.ToArray());
        }
        public object NewPassengerPlane(byte[] data)
        {
            List<string> list = new List<string>();
            int position = 0;
            list.Add(Encoding.UTF8.GetString(data, position, 3));
            position += 3;
            position += 4;
            list.Add(Encoding.UTF8.GetString(data, position, 8));
            position += 8;
            list.Add(Encoding.UTF8.GetString(data, position, 10));
            position += 10;
            list.Add(Encoding.UTF8.GetString(data, position, 3));
            position += 3;
            list.Add(Encoding.UTF8.GetString(data, position, 2));
            position += 2;
            var ML = Encoding.UTF8.GetString(data, position, 2);
            position += 2;
            list.Add(Encoding.UTF8.GetString(data, position, int.Parse(ML)));
            position += int.Parse(ML);
            list.Add(Encoding.UTF8.GetString(data, position, 2));
            position += 2;
            list.Add(Encoding.UTF8.GetString(data, position, 2));
            position += 2;
            list.Add(Encoding.UTF8.GetString(data, position, 2));
            position += 2;

            FileReader fileReader = new FileReader();
            return fileReader.objectFactory["PP"](list.ToArray());
        }
        public object newAirPort(byte[] data)
        {
            List<string> list = new List<string>();
            int position = 0;
            list.Add(Encoding.UTF8.GetString(data, position, 3));
            position += 3;
            
            position += 4;
            list.Add(Encoding.UTF8.GetString(data, position, 8));
            position += 8;
            var NameL = Encoding.UTF8.GetString(data, position, 2);
            position += 2;
            list.Add(Encoding.UTF8.GetString(data, position, int.Parse(NameL)));
            position += int.Parse(NameL);
            list.Add(Encoding.UTF8.GetString(data, position, 3));
            position += 3;
            list.Add(Encoding.UTF8.GetString(data, position, 4));
            position += 4;
            list.Add(Encoding.UTF8.GetString(data, position, 4));
            position += 4;
            list.Add(Encoding.UTF8.GetString(data, position, 4));
            position += 4;
            list.Add(Encoding.UTF8.GetString(data, position, 3));
            position += 3;


            FileReader fileReader = new FileReader();
            return fileReader.objectFactory["AI"](list.ToArray());
        }
        public object NewFlight(byte[] data)
        {
            List<string> list = new List<string>();
            int position = 0;
            list.Add(Encoding.UTF8.GetString(data, position, 3));
            position += 3;
            
            position += 4;
            list.Add(Encoding.UTF8.GetString(data, position, 8));
            position += 8;
            list.Add(Encoding.UTF8.GetString(data, position, 8));
            position += 8;
            
            list.Add(Encoding.UTF8.GetString(data, position, 8));
            position += 8;
            list.Add(Encoding.UTF8.GetString(data, position, 8));
            position += 8;
            list.Add(Encoding.UTF8.GetString(data, position, 8));
            position += 8;
            
            list.Add(Encoding.UTF8.GetString(data, position, 8));
            position += 8;
            list.Add(Encoding.UTF8.GetString(data, position, 2));
            position += 2;
            var count = Encoding.UTF8.GetString(data, position, 2);
            position += 2;
            list.Add(Encoding.UTF8.GetString(data, position, int.Parse(count)));
            position += 8*int.Parse(count);
            list.Add(BitConverter.ToString(data, position));
            position += 2;
            var Pcount = Encoding.UTF8.GetString(data, position, 2);
            position += 2;
            list.Add(Encoding.UTF8.GetString(data, position, int.Parse(Pcount)));
            position += 8 * int.Parse(Pcount);

            FileReader fileReader = new FileReader();
            return fileReader.objectFactory["FL"](list.ToArray());
        }

    }
}
